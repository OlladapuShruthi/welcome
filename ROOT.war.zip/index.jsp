<html>
<head>
    <title>My Tomcat App</title>
</head>
<body>
    <h1>Hello from Elastic Beanstalk (Tomcat) 🚀</h1>
</body>
</html>
